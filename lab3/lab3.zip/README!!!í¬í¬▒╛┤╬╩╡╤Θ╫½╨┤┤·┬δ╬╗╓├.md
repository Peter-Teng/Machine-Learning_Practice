﻿## 机器学习 第三次实验 AdaBoost与人脸检测
本次实验编写的源代码在四个py文件中:
Pic-Process.py用于将图片转化为32*32的灰度图像
extract_feature.py用于提取灰度图像的特征
train.py调用实现的Adaboost类
ensemble.py 实现了AdaboostClassifier

结果存在classifier_report.txt中
[基于AdaBoost算法的人脸检测](https://www.zybuluo.com/mymy/note/1621330)
