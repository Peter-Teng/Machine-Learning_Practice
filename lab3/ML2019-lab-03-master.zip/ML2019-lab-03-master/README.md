## 机器学习 第三次实验 AdaBoost与人脸检测
[基于AdaBoost算法的人脸检测](https://www.zybuluo.com/mymy/note/1621330)
